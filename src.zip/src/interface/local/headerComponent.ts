export interface HeaderComponent {
    Main: string
    Patients: string
    Branches: string
    Specialists: string
    lang: string,

}