

export interface BannerComponent {
    phoneNumber: string,
    freeSeats: string,
    titie: string,
    send: string,
}