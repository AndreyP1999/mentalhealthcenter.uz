
import { ListDepartmentComponent } from "@/interface/local/main/listDepartmentComponents";
import Headings from "@/UI/headings/Headings";
import ItemDepartment from "./item/itemDepartment";
import data from "./testData";


function ListDepartment({ localizate }: { localizate: ListDepartmentComponent }) {
    return (
        <section className="my-5 Open_Sans container mx-auto">
            <Headings level={2} text={localizate?.titie} />
            <ol className="flex flex-col gap-10">
                {data.map((department, index) => <ItemDepartment key={department.id} department={department} /> 
                )}
            </ol>
        
        </section>
    );
}

export default ListDepartment;