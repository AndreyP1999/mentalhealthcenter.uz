import department from "@/interface/department";
import { ListDepartmentComponent } from "@/interface/local/main/listDepartmentComponents";
import Image from "next/image";
import Link from "next/link";
import style from "./style.module.css";

function ItemDepartment({ department }: { department: department }) {
    return (
        <li key={department.id}>
            <div className="flex flex-col gap-5 ">
                <input className={style.openMenu} defaultChecked type="checkbox" hidden id={`department_${department.id}`} />
                <label className={style.dropMenu__title} htmlFor={`department_${department.id}`}>
                    {department.name}
                </label>
                <nav className={style.my_grid}>
                    {department.children.map((el,index) => {
                        return (
                            <Link key={index} className={style.item} href={el.url}>
                                <span className="IBM_Plex_Sans">{el.text}</span>
                                <Image className="self-end" src="/image/arrowLeft.svg" alt="arrowLeft" width={64} height={64} />
                            </Link>
                        )
                    })}
                </nav>
            </div>
        </li>
    );
}

export default ItemDepartment;