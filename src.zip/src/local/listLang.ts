export const languages = ["en", "uz"]
export const mainLanguages = "ru"
export const allLanguages = ["en", "uz", "ru"]