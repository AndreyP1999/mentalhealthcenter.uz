export default interface branches{
    id:number,
    name:string,
    address: string,
    chief:string,
    phone:string
}