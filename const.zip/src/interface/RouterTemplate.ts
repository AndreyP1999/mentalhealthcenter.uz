export interface IRoutesMap {
    [index: string]: JSX.Element;
}

