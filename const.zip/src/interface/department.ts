
export default interface department {
    id:number,
    name: string,
    children: Array<{ text: string, url: string }>
}