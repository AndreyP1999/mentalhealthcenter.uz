export interface localizationPatientsPage {
    bannerText: string;
    title: string;
    file_name: string;
    find: string;
    upload_date: string;
    download: string;
    download_all: string;
}