export interface ListDepartmentComponent {
    titie: string,
 
}