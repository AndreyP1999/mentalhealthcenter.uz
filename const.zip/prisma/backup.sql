INSERT INTO public."BranchesEN"(name, address, "Chief", url, id_phone)
VALUES ('Андижанский филиал РСНПМЦН', 'г. Андижан, ул. Ю.Отабеков 3 д.','Махмудова Нигора Акбаровна','/', 1);

INSERT INTO public."BranchesEN"(name, address, "Chief", url, id_phone)
VALUES ('Бухарский филиал РСНПМЦН', 'г.Бухара, ул.Жуйбор 15','Холов Жахон Истамович','/',2);

INSERT INTO public."BranchesEN"(name, address, "Chief", url, id_phone)
VALUES ('Джизакский филиал РСНПМЦН','г.Джизак махалля Оккоргон ул.Саиднасимов О. 69 д','Мелибоев Қахрамон Эшпўлатович','/',3);

INSERT INTO public."BranchesEN"(name, address, "Chief", url, id_phone)
VALUES ('Кашкадарьинский филиал РСНПМЦН','г.Карши махаля Табассум ул.Садыкова 7 / 1','Мухаммаджонов Боходир Мухаммаджонович','/',4);

INSERT INTO public."BranchesEN"(name, address, "Chief", url, id_phone)
VALUES ('Капакалпакстан филиал РСНПМЦН', 'Г.Нукус ул.Бекманов 114','Турумбетов Рамберген','/',5);

INSERT INTO public."BranchesEN"(name, address, "Chief", url, id_phone)
VALUES ('Навоийский филиал РСНПМЦН', 'Навои ул.Миморлар 2','Норов Сувон Норович','/',6);

INSERT INTO public."BranchesEN"(name, address, "Chief", url, id_phone)
VALUES ('Наманганский филиал РСНПМЦН','Наманган ул.Навои 70','Дадабоев Файзулло Убайдуллаевич','/',7);

INSERT INTO public."BranchesEN"(name, address, "Chief", url, id_phone)
VALUES ('Самаркандский филиал РСНПМЦН', 'Самарканд ул.Али Кушчи 15А','Кенжаева Наргиза Қувватовна','/',8);

INSERT INTO public."BranchesEN"(name, address, "Chief", url, id_phone)
VALUES ('Сырдарьинский филиал РСНПМЦН','Гулистан махалля Ибн Сино 20 2. г.Пахтабод р - н Сардоба махаля Чулпон 40 д','Шералиев Афис Сабирович','/',9);

INSERT INTO public."BranchesEN"(name, address, "Chief", url, id_phone)
VALUES ('Сурхандарьинский филиал РСНПМЦН','г.Термез ул.Жумы Гаирова 5','Ишбабаев Джума Мадиевич','/',10);

INSERT INTO public."BranchesEN"(name, address, "Chief", url, id_phone)
VALUES ('Ташкентский городской филиал РСНПМЦН', 'г.Ташкент Чиланзарский район, квартал 2, ул.Арнасай 32','Алимходжаев Равшан Саидазимович','/',11);

INSERT INTO public."BranchesEN"(name, address, "Chief", url, id_phone)
VALUES ('Ташкентский областной филиал РСНПМЦН','г.Ангрен, махаля Оппартак, ул.Обод турмуш, 20 д','Газиев Ахил Адилович','/',12);

INSERT INTO public."BranchesEN"(name, address, "Chief", url, id_phone)
VALUES ('Ферганский филиал РСНПМЦН', 'г.Фергана, ул.Янгизамон 61','Ибрагим Бобурбек','/',13);

INSERT INTO public."BranchesEN"(name, address, "Chief", url, id_phone)
VALUES ('Хорезмский филиал РСНПМЦН', 'Хивинский район, село Шомахулум','Шарипов Алишер Олимбоевич','/',14);